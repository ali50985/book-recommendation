import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import pickle

# Load the dataset
books_df = pd.read_csv('books.csv')  # Ensure books.csv is in the same directory

# Verify that the 'title' column exists
if 'title' not in books_df.columns:
    raise ValueError("The dataset must contain a 'title' column.")

# Vectorize the book titles
count_vectorizer = CountVectorizer(stop_words='english')
count_matrix = count_vectorizer.fit_transform(books_df['title'])

# Compute the similarity matrix
similarity_matrix = cosine_similarity(count_matrix)

# Save the similarity matrix
with open('similarity_matrix.pkl', 'wb') as file:
    pickle.dump(similarity_matrix, file)

# Save the processed books dataset for reference
books_df.to_csv('processed_books.csv', index=False)

print("Similarity matrix has been saved as 'similarity_matrix.pkl'.")
print("Processed books dataset has been saved as 'processed_books.csv'.")
