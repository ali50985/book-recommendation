from flask import Flask, render_template, request
import pickle
import pandas as pd

app = Flask(__name__)

# Load the book data and similarity matrix
books_df = pd.read_csv('processed_books.csv')  # Ensure this file exists
similarity_matrix = pickle.load(open('similarity_matrix.pkl', 'rb'))

# Function to get book recommendations
def get_recommendations(book_title):
    if book_title not in books_df['title'].values:
        raise KeyError("Book not found in the dataset.")
    
    # Find the index of the given book
    book_index = books_df[books_df['title'] == book_title].index[0]
    
    # Get a list of similar books based on the similarity matrix
    similar_books = sorted(
        list(enumerate(similarity_matrix[book_index])),
        key=lambda x: x[1], reverse=True
    )[1:6]  # Top 5 similar books
    
    # Return the titles of the recommended books
    recommended_titles = [books_df.iloc[i[0]]['title'] for i in similar_books]
    return recommended_titles

# Routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/recommend', methods=['POST'])
def recommend():
    book_name = request.form.get('book')  # Get the book name from the form input
    
    if not book_name:
        # If no book title is provided
        return render_template('recommendations.html', book_name=book_name, recommended_books=[])
    
    try:
        # Get book recommendations using the ML model
        recommended_books = get_recommendations(book_name)
    except KeyError:
        # If the book title is not found in the dataset
        recommended_books = []
    
    # Pass the book name and recommendations to the template
    return render_template('recommendations.html', book_name=book_name, recommended_books=recommended_books)

if __name__ == '__main__':
    app.run(debug=True)
